# New Agent for Notes and Stats

Prepared for Vincent. Repository: Vncntmhlr/CIS_Assignments. Only permitted target branch: dev/vincent.

## Contents
- AGENTS.md: Vincent's original instructions plus branch isolation and three task profiles.
- CLAUDE.md: imports AGENTS.md.
- assignment2/REPORT_NOTES.md: separate snapshot of Vincent's existing report notes at commit b03ce964f2f5c352cf08058c24c36f8eadd6f9ce. Existing links resolve when placed in the repository's assignment2 directory.
- assignment2/WORKING_NOTES.md: new empty technical-notes scaffold for Vincent.
- skills/: three separate Vincent-specific skills, each with SKILL.md and agents/openai.yaml.

## Use
1. Use your own GitHub connection with access to the repository. This package contains no credentials.
2. Check out dev/vincent and review the diff before applying AGENTS.md. Preserve any newer instructions and TA protections.
3. Create WORKING_NOTES.md only if it does not already exist; otherwise preserve and merge existing notes. REPORT_NOTES.md is a reference snapshot: do not overwrite newer report content with it.
4. Install each skill folder using the custom-skill import supported by your AI tool. If it accepts one skill ZIP at a time, ZIP the individual folder with its SKILL.md and agents directory. Uploading this bundle to GitHub alone does not install skills.
5. Invoke cis-working-notes-vincent to capture points, cis-report-notes-vincent to draft explanatory sections, or cis-report-stats-vincent to validate evidence and write Validation Approach, Final Results, and Conclusion. Both report skills read current working notes first.

All instructions restrict writes to dev/vincent. These are workflow restrictions, not GitHub permission enforcement. Configure GitHub access separately for enforced isolation. No live Vincent files were changed when this archive was prepared.
