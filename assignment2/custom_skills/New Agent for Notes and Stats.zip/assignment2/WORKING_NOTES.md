# Assignment 2 — Vincent Working Notes

Branch: `dev/vincent`. Capture requested points here. These notes support report writing and validation; they are not proof that experiments ran.

## Concepts and Equations
No discussion points captured yet.

## Decisions and Proposed Methods
No new decisions captured yet. Existing report material is in [REPORT_NOTES.md](REPORT_NOTES.md).

## Open Questions
No questions captured yet.

## Verified Evidence
No new experiments performed while packaging these files.

