# CIS_Assignments

JHU Computer Integrated Surgery I, Fall 2026; one repository for assignments 1–4.

## Sources and organization
- Project: https://github.com/Vncntmhlr/CIS_Assignments
- Official TA/course repository: https://github.com/LCSR-CIIS/CIS_I_Course/tree/main
- Prefer local assignment briefs, READMEs, notebooks, and source files. Fetch upstream resources only when relevant to the task (e.g. a missing reference or requested comparison/update); do not routinely browse, clone, or pull upstream.
- `assignment1/`: pivot calibration. Student work is in `functions/` and `notebooks/assignment1_final.ipynb`; the report is `notebooks/CIS_I_Assignment1_Report_Final.pdf`. `archive_notebooks/` contains historical experiments, not the primary entry point.
- `assignment1/src/` (including `simulation/`), `data_types/`, and `uncertainty_networks/` contain course support code. Preserve these unless explicitly asked to modify them.
- `assignment2/`: current work; brief: `2026_assignment_2.pdf`. `assignment3/` and `assignment4/` are placeholders. Keep each assignment's code and documentation in its own directory.
- `.local_archive/` holds ignored local backups, including a course checkout; consult only as relevant reference, not as the active implementation.
- For Assignment 2, when implementing or selecting mathematical methods (e.g., registration, calibration, interpolation, least squares, covariance propagation, or kinematics-related derivations), prioritize the methods documented in `assignment2/CIS_I_Assignment2_Classroom_Math_Methods.md` before considering alternative approaches. Alternative methods may be used when justified by accuracy, numerical stability, or runtime requirements.

## Vincent branch and task profiles
- These instructions and bundled skills target only `Vncntmhlr/CIS_Assignments`, branch `dev/vincent`. Explicitly specify this branch for every repository read/write. Never commit to dev/ahmed, main, or another branch. Do not merge, create branches, force-push, or change repository settings.
- Before local edits verify the checkout is dev/vincent and preserve existing changes. Before remote writes verify the target and current file SHA; on conflicts refetch and reconcile. Refuse cross-branch writes under this package.
- CIS Working Notes — Vincent: capture requested discussion in assignment2/WORKING_NOTES.md. Development is inactive; do not run experiments or edit report results.
- CIS Report Notes — Vincent: read WORKING_NOTES.md and REPORT_NOTES.md every invocation and draft explanatory report sections. Development is inactive. Preserve validation/results/conclusion sections unless a supported prose edit is explicitly requested.
- CIS Report Stats — Vincent: read WORKING_NOTES.md and REPORT_NOTES.md every invocation, then apply Development to requested validation/analysis. Write under Validation Approach, Final Results, and Conclusion. Distinguish plans, preliminary measurements, and verified results.
- Common source, collaboration, report-quality and TA protection rules apply to all profiles. Assignment 1 remains a structure/quality reference, not Assignment 2 evidence.
- Skills do not run in the background. A requested notes save authorizes its documentation commit on dev/vincent; merely loading instructions does not authorize a write.
- The bundled report is a snapshot. Read current branch files before use; never overwrite newer notes with a packaged snapshot.

## Development

Active for CIS Report Stats — Vincent and ordinary implementation/validation; inactive for the two note-writing profiles.
- Follow the relevant assignment README and brief. Assignment 1 uses Python 3.9+ and `assignment1/requirements.txt`; use an isolated environment.
- Follow existing Python/NumPy conventions and naming. Preserve coordinate-frame meanings, units, array shapes, and numerical assumptions; explain non-obvious mathematics.
- Preserve notebook relative imports: execute Assignment 1's final notebook with `assignment1/notebooks/` as the working directory.
- Validate changes with focused numerical checks and relevant notebooks; for notebook changes, restart the kernel and run all cells when feasible. Account for simulation randomness and report checks run or limitations.
- Avoid unrelated notebook output churn; do not add environments, caches, or generated artifacts unless required for the task.


## TA Starter Code and Template Protection

- Treat all TA-provided starter files as read-only reference material by default.
- Do not add student-created files inside TA-provided folders. For Assignment 2, keep helpers in the existing `vendor/functions/`, additional tests and essential experiment scripts in `experiments/`, and reusable datasets, fitted parameters and essential outputs in `results/`. Reuse these folders; preserve the original `src/student/` and `tests/` file lists.
- In the assignment notebook, only modify code explicitly marked `TODO` or clearly designated for student implementation.
- Never modify, rewrite, shorten, expand, or reorganize TA-provided Markdown cells, including the instructions above each code cell, unless explicitly requested by the user.
- Do not modify non-TODO code cells, original equations, examples, evaluation procedures, or notebook structure without explicit permission.
- Do not alter TA-provided test cases, assertions, or expected results. Only implement tests explicitly marked as student TODOs when requested.
- Do not change TA-provided simulation modules or APIs.
- If a necessary implementation appears to require changes outside the designated TODO areas, explain the reason and request permission before editing.
- Prefer creating separate experimental files rather than modifying protected starter content.
- Before completing a task, review the Git diff and ensure no unintended changes were made to protected content.
- Preserve the original TA notebook template whenever possible; use a separate working copy for student development.


## Collaboration
- Inspect the working tree before edits, preserve user changes, and keep changes scoped to the request. Do not change other assignments or course simulation code incidentally.
- Explain material assumptions, mathematical changes, and validation results. Ask when requirements are ambiguous enough to affect correctness.
- Do not commit, push, or change GitHub settings unless the user requests it. Keep shared instructions here; `CLAUDE.md` imports this file.

## Report-Oriented Documentation
- Maintain `REPORT_NOTES.md` inside each assignment directory for report-worthy material only: major design decisions, mathematical derivations and key equations, algorithmic approaches, important experimental settings and quantitative results, validation evidence, and meaningful limitations.
- Keep environment/setup checks, dependency/import results, and setup test summaries out of report notes. Put necessary runtime instructions in `SETUP.md`; retain algorithmic validation relevant to the final report.
- Update notes after significant milestones, not every interaction or minor code change. Organize by topic, consolidate superseded material, and avoid repetitive activity logs. Preserve links to relevant code, figures, tables, and test results; distinguish measured evidence from planned work.
- Target approximately 20 pages for the final report, following the general quality and structure of Assignment 1's report while avoiding unnecessary length; official assignment requirements take precedence.
- Focus the report's unit-test discussion on approximately 2–4 high-value tests, especially kinematics tests. Still implement and run all officially required tests; the discussion limit does not reduce testing requirements.

